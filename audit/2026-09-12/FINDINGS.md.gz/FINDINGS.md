# BURGAMOTS Findings

Frozen repository: `AlkaiDynamics/BURGAMOTS` @ `8a9029b69b107d4230c9f053b4c8ef545a99e90e`.

**Overall bounded verdict:** **Does not currently establish a valid falsification test for BURGAMOTS’ original purpose.** This is a verdict on the audited artifact and its evidentiary chain, not a finding that the underlying zodiacal, harmonic, heliophysical, or deterministic hypotheses are false.

## Defect ledger summary

- Findings: **47** total — Critical 23, Major 21, Minor 2, Unresolved 1.
- Every Critical/Major finding below includes its strongest defense and whether the finding survives that defense.

## Evidence

The artifact presents many empirical/performance conclusions, but the decisive numbers are not connected to inspectable scientific runs or data artifacts.

### E-001 — Critical / High confidence

**Observed finding:** The repository does not preserve the owner-supplied original zodiac/relational falsification purpose as its stated operational purpose.

**Evidence:** metadata.json describes deterministic heliospheric prediction; README/FullPaper central hypotheses concern planetary forcing of solar/atmospheric dynamics.

**Validity implication:** The audited artifact cannot, by itself, show that it is testing the experiment for which BURGAMOTS was originally created.

**Resolution criterion (not a remediation prescription):** Requires an inspectable statement of the original target and an operational claim-to-test mapping.

**Strongest defense:** The project may have intentionally pivoted or used a public-facing framing while retaining the original purpose elsewhere.

**Survives defense:** Yes

**Evidence that would change the finding:** A repository artifact at or before the cutoff showing the original purpose and its executable test would narrow or remove this finding.

### E-002 — Critical / High confidence

**Observed finding:** Decisive empirical claims lack inspectable result artifacts linking claim → run → configuration → code → data.

**Evidence:** Repository tree contains frontend/config files but no result tables, run manifests, checkpoints, notebooks, datasets, or experiment records.

**Validity implication:** Reported performance and significance cannot be independently reconstructed from the artifact.

**Resolution criterion (not a remediation prescription):** Requires traceable result artifacts with immutable run/data/config identifiers.

**Strongest defense:** Results could have been produced externally and copied into the frontend.

**Survives defense:** Yes

**Evidence that would change the finding:** External artifacts with verifiable provenance to the displayed claims would change this finding.

### E-003 — Critical / High confidence

**Observed finding:** Validation/performance quantities are embedded as literal source values rather than generated from an inspectable analysis path.

**Evidence:** components/ValidationCharts.tsx, SolarCycleChart.tsx, App.tsx validation summary.

**Validity implication:** The code proves only that these values are displayed, not that the stated experiments produced them.

**Resolution criterion (not a remediation prescription):** Requires a generated result artifact or executable computation tied to source data.

**Strongest defense:** Hardcoded values are normal for a presentation layer when authoritative results exist elsewhere.

**Survives defense:** Yes

**Evidence that would change the finding:** A traceable upstream result source would reduce this from unsupported evidence to presentation-only implementation.

### E-004 — Major / High confidence

**Observed finding:** The textual flare claim r=0.89 is not the Pearson correlation of the 20 mock points rendered by FlareCorrelationChart (approximately 0.847).

**Evidence:** FlareCorrelationChart.tsx literal mock array; App.tsx §4.4 r=0.89 text.

**Validity implication:** The displayed statistical claim is internally inconsistent with the only plotted data in the artifact.

**Resolution criterion (not a remediation prescription):** Requires the exact dataset/statistic underlying r=0.89 or a matching recomputation.

**Strongest defense:** The r=0.89 value may refer to a different external dataset than the mock chart.

**Survives defense:** Yes

**Evidence that would change the finding:** A provenance-linked external dataset/result for r=0.89 would change the claim-to-chart interpretation.

### E-005 — Major / High confidence

**Observed finding:** Cycle-25 error percentages and displayed observed value use different apparent denominators without an exposed definition.

**Evidence:** SolarCycleChart.tsx labels Observed (2024)=162; App/README table reports errors consistent with comparison to ~160.

**Validity implication:** A reader cannot reconstruct the performance metric from the UI alone.

**Resolution criterion (not a remediation prescription):** Requires explicit observed target definition/date/denominator and generated calculation.

**Strongest defense:** README explicitly says “relative to Obs ~160,” so the percentages may be internally intended against 160 rather than 162.

**Survives defense:** Yes

**Evidence that would change the finding:** A single declared target and calculation provenance would resolve the ambiguity.

### E-006 — Critical / High confidence

**Observed finding:** The repository availability claim for complete DeepXDE code, preprocessed JPL data, notebooks, and custom losses is contradicted by the audited tree.

**Evidence:** README.md §10.3 and FullPaper.tsx §10.3 versus recursive tree and package.json.

**Validity implication:** The reproducibility claim is false for this repository/commit as inspected.

**Resolution criterion (not a remediation prescription):** Requires the claimed artifacts to be inspectably associated with this repository/commit or the claim to refer accurately to their actual location.

**Strongest defense:** Those artifacts may exist in a private repository, untracked storage, or another historical branch.

**Survives defense:** Yes

**Evidence that would change the finding:** Evidence that the cited “project GitHub repository” unambiguously refers to another accessible source containing the artifacts would change scope.

## Experimental design

The original falsification target is not operationalized, and the public heliophysics hypotheses lack a coherent implemented null/evaluation design.

### D-001 — Critical / High confidence

**Observed finding:** The implemented/public experiment addresses planetary-forcing heliophysics, not the original question of incremental zodiacal/relational predictive efficacy.

**Evidence:** metadata.json, README hypotheses, App hypothesis cards; no operational zodiac comparison in audited tree.

**Validity implication:** A positive or negative result from the present public design would not directly falsify the original zodiac proposition.

**Resolution criterion (not a remediation prescription):** Requires an explicit original-purpose claim with a discriminating control design.

**Strongest defense:** The public mechanism may have been chosen as an indirect physical test of a broader relational idea.

**Survives defense:** Yes

**Evidence that would change the finding:** A documented derivation proving the public test is a valid necessary/sufficient test of the original claim would change this.

### D-002 — Critical / High confidence

**Observed finding:** Displayed falsifiability rules are directionally/inferentially inconsistent with the stated nulls.

**Evidence:** App.tsx: solar card says “Reject H₀ if r < 0.85”; atmospheric card says “Reject H₀ if RMSE > 10%”; abstract shows “Reject if p ≥ 0.001.”

**Validity implication:** The stated decision rules can reject a no-effect null on weak correlation/worse error or large p, so they do not form a coherent falsification protocol.

**Resolution criterion (not a remediation prescription):** Requires a prespecified decision rule mathematically matched to each null/estimand.

**Strongest defense:** “Reject” might have meant reject BURGAMOTS rather than reject H₀.

**Survives defense:** Yes

**Evidence that would change the finding:** The cards explicitly label “Reject H₀,” so only evidence of a different intended semantics in the governing protocol would change this finding.

### D-003 — Critical / High confidence

**Observed finding:** No credible null/control implementation for the original purpose is present.

**Evidence:** No executable comparison against ordinary astronomy/time baselines, rotated zodiac, alternative partitions, randomized relations, or analogous negative controls in tree.

**Validity implication:** The artifact cannot distinguish target relational information from generic astronomical periodicity or flexible representation choice.

**Resolution criterion (not a remediation prescription):** Requires a prespecified null/control that preserves nuisance structure while removing the target relation.

**Strongest defense:** The original experiment may exist outside this repository.

**Survives defense:** Yes

**Evidence that would change the finding:** An inspectable external experiment linked to this artifact could change status.

### D-004 — Critical / High confidence

**Observed finding:** Unit of analysis, sampling frame, independent unit, primary outcome, and evaluation boundary for the original purpose are unspecified.

**Evidence:** Original-purpose experiment absent from repository; public hypotheses do not supply these fields sufficiently for the original target.

**Validity implication:** Effect estimates, uncertainty, exchangeability, and falsification thresholds cannot be interpreted.

**Resolution criterion (not a remediation prescription):** Requires those design quantities to be declared before evaluation.

**Strongest defense:** They may have been informally understood by the creator.

**Survives defense:** Yes

**Evidence that would change the finding:** A dated protocol defining these quantities would resolve the finding.

### D-005 — Major / High confidence

**Observed finding:** Named validation cases are selectively foregrounded without a declared event census or case-selection rule.

**Evidence:** App.tsx validation emphasizes Carrington, Dust Bowl, and SC25; no all-event sampling frame located.

**Validity implication:** Success on selected historical extremes cannot establish event-general performance or exclude selection effects.

**Resolution criterion (not a remediation prescription):** Requires a declared sampling frame/case inclusion rule or prospectively selected cases.

**Strongest defense:** Case studies may have been intended as illustrations rather than inferential samples.

**Survives defense:** Yes

**Evidence that would change the finding:** If explicitly illustrative and not used as validation evidence, severity would fall.

### D-006 — Major / High confidence

**Observed finding:** Predictive association, physical mechanism, and causal interpretation are not cleanly separated in the claim structure.

**Evidence:** App/README move from correlation/hindcast to “primary synchronization mechanism,” “causal flow,” and deterministic encoding.

**Validity implication:** Predictive success alone cannot identify the proposed tidal/MHD mechanism.

**Resolution criterion (not a remediation prescription):** Requires mechanism-specific discriminating tests separate from predictive efficacy.

**Strongest defense:** The paper presents a mechanistic hypothesis, not merely a statistical model.

**Survives defense:** Yes

**Evidence that would change the finding:** Direct mechanism-specific evidence independent of forecasting association would change this finding.

### D-007 — Major / High confidence

**Observed finding:** Cycle-26 rejection bounds (>180 or <80) are asserted without an inspectable derivation, error model, power, or operating characteristics.

**Evidence:** README.md §7.2 Falsifiability Protocol.

**Validity implication:** The future falsification rule may be arbitrary or too permissive/strict to interpret.

**Resolution criterion (not a remediation prescription):** Requires the bounds to follow from a frozen model/predictive distribution and declared outcome definition.

**Strongest defense:** Broad bounds can still be a legitimate strong falsifier if they were genuinely prespecified.

**Survives defense:** Yes

**Evidence that would change the finding:** A timestamped derivation from the model predictive distribution would change this.

## Statistics

Displayed inferential claims are not generated by an inspectable statistical analysis and omit essential dependence, multiplicity, uncertainty, or test-definition information.

### S-001 — Major / High confidence

**Observed finding:** The Granger chart hardcodes F=4.0 as “p<0.01” without degrees of freedom or a computed test.

**Evidence:** ValidationCharts.tsx grangerData and ReferenceLine.

**Validity implication:** An F statistic has no universal p-value threshold; significance depends on model/test degrees of freedom and assumptions.

**Resolution criterion (not a remediation prescription):** Requires generated p-values or critical values from the specified Granger model.

**Strongest defense:** For some degrees of freedom F≈4 can correspond to p<0.01.

**Survives defense:** Yes

**Evidence that would change the finding:** A specified model/df showing the displayed threshold is correct would resolve it.

### S-002 — Major / High confidence

**Observed finding:** The UI interprets Granger significance as “significant causal flow,” exceeding what Granger predictive precedence establishes by itself.

**Evidence:** App.tsx causal-analysis caption.

**Validity implication:** The interface promotes predictive temporal association to physical causality without excluding confounding/common periodic drivers.

**Resolution criterion (not a remediation prescription):** Requires causal identification assumptions/evidence beyond Granger prediction.

**Strongest defense:** “Granger causality” is standard terminology in time-series analysis.

**Survives defense:** Yes

**Evidence that would change the finding:** The standard name does not justify “physical causal flow”; a narrowly worded predictive interpretation would alter this finding.

### S-003 — Major / High confidence

**Observed finding:** No multiplicity policy is documented for the many lags, outcomes, events, model comparisons, and relational hypotheses presented.

**Evidence:** Multiple validation cases/lags/metrics in App/README/ValidationCharts; no FWER/FDR/primary-outcome policy found.

**Validity implication:** Nominal significance can be inflated by search across hypotheses and lags.

**Resolution criterion (not a remediation prescription):** Requires declared primary tests and/or multiplicity/search-space accounting.

**Strongest defense:** Some displayed statistics could come from a single prespecified analysis elsewhere.

**Survives defense:** Yes

**Evidence that would change the finding:** A dated prespecification establishing a single primary analysis would narrow this concern.

### S-004 — Major / High confidence

**Observed finding:** Stationarity, autocorrelation, effective sample size, and surrogate/phase controls are not documented or executable for the periodic time-series claims.

**Evidence:** README/App time-series hypotheses and Granger/correlation claims; no analysis code.

**Validity implication:** Periodic/autocorrelated series can yield misleading correlations and nominal significance under independence assumptions.

**Resolution criterion (not a remediation prescription):** Requires a time-series inference specification appropriate to the dependence structure.

**Strongest defense:** The absent external analysis may have handled these issues.

**Survives defense:** Yes

**Evidence that would change the finding:** Traceable analysis artifacts documenting the treatment would change this.

### S-005 — Critical / High confidence

**Observed finding:** Displayed uncertainty/confidence quantities (±12, ±15, 95%, 5σ, 99.8%, 94.2%) have no inspectable estimand, sampling distribution, or generation path.

**Evidence:** Hero.tsx, Navigation.tsx, App.tsx, SolarCycleChart.tsx, README Cycle26.

**Validity implication:** Uncertainty and confidence cannot be interpreted or audited.

**Resolution criterion (not a remediation prescription):** Requires definition and generated uncertainty artifacts tied to runs/data.

**Strongest defense:** They may be copied from external experiments not committed here.

**Survives defense:** Yes

**Evidence that would change the finding:** Provenance-linked calculations would resolve this.

### S-006 — Critical / High confidence

**Observed finding:** “Blind test” and generalization claims have no inspectable holdout split or evaluation protocol.

**Evidence:** App.tsx Validation Summary; no split code/run artifacts in tree.

**Validity implication:** The audit cannot establish that the reported score estimates performance on unseen information.

**Resolution criterion (not a remediation prescription):** Requires a reconstructable data/model freeze and held-out evaluation boundary.

**Strongest defense:** A blind evaluation may have been conducted manually/off-repo.

**Survives defense:** Yes

**Evidence that would change the finding:** Timestamped blind-test artifacts would change this.

### S-007 — Major / High confidence

**Observed finding:** No seed/split sensitivity analysis or repeated-evaluation evidence is inspectable for the claimed scientific models.

**Evidence:** No scientific model code/config/run artifacts; frontend uses unseeded Math.random only for visuals.

**Validity implication:** Reported model performance robustness cannot be assessed.

**Resolution criterion (not a remediation prescription):** Requires repeat-run/split records for any stochastic scientific training procedure.

**Strongest defense:** L-BFGS/PINN training could have been made deterministic externally.

**Survives defense:** Yes

**Evidence that would change the finding:** External run manifests would change status.

## Implementation

The frontend/visualizer is substantive, but it does not implement the documented DeepXDE/PINN/JPL scientific engine; several scientific-sounding visual quantities are simplified proxies.

### I-001 — Critical / High confidence

**Observed finding:** The documented DeepXDE/PINN/MHD scientific engine is absent from the repository runtime and dependency graph.

**Evidence:** package.json and package-lock contain frontend dependencies only; recursive tree contains no Python/notebook/model implementation.

**Validity implication:** The implementation does not execute the stated scientific method at this commit.

**Resolution criterion (not a remediation prescription):** Requires executable scientific code corresponding to the documented method to be inspectable.

**Strongest defense:** The frontend repository may have been intentionally separated from a scientific backend.

**Survives defense:** Yes

**Evidence that would change the finding:** If documentation clearly points to and versions a separate backend, this becomes a repository-boundary issue rather than absence.

### I-002 — Critical / High confidence

**Observed finding:** The documented JPL/SDO/ERA5/OISST ingestion and preprocessing pipeline is not implemented in the audited code.

**Evidence:** Diagrams.tsx depicts pipeline; no data files/acquisition scripts/network fetch path for science data in tree.

**Validity implication:** Displayed scientific outputs cannot be traced to the stated source datasets.

**Resolution criterion (not a remediation prescription):** Requires inspectable acquisition/preprocessing execution or immutable prepared inputs.

**Strongest defense:** Data may have been precomputed externally and manually embedded.

**Survives defense:** Yes

**Evidence that would change the finding:** Traceable prepared inputs and transformation provenance would change the finding.

### I-003 — Critical / High confidence

**Observed finding:** `calculateTorqueIndex(year)` is a normalized sum of 11.07-year and 19.86-year sine waves, not the documented physical planetary torque r×F or a PINN output.

**Evidence:** SolarSystemViz.tsx `calculateTorqueIndex`; README §4.1 describes torque computed from position/force vectors.

**Validity implication:** The quantity labeled Torque Index in the visualization does not implement the stated physical quantity.

**Resolution criterion (not a remediation prescription):** Requires an operational definition showing equivalence or an executable physical-torque computation.

**Strongest defense:** It may be intended only as a visual resonance proxy.

**Survives defense:** Yes

**Evidence that would change the finding:** If UI and documentation consistently identify it as a nonphysical illustrative proxy, the validity severity would fall for visualization use.

### I-004 — Critical / High confidence

**Observed finding:** The orbital visualizer uses simplified 2-D Kepler propagation from hardcoded elements rather than JPL state vectors or interacting N-body integration.

**Evidence:** SolarSystemViz.tsx `getPlanetPositionHeliocentric`; stored inclination/node values are not used in returned x/y; no JPL client/integration engine.

**Validity implication:** The visualizer cannot serve as evidence that the claimed JPL/N-body scientific computation is running.

**Resolution criterion (not a remediation prescription):** Requires method equivalence to be demonstrated or the visualizer to be treated as an approximation only.

**Strongest defense:** A simplified visual ephemeris is entirely reasonable for interactive rendering.

**Survives defense:** Yes

**Evidence that would change the finding:** This finding concerns scientific-method equivalence, not visual quality; explicit separation would narrow severity.

### I-005 — Major / High confidence

**Observed finding:** The Helical Tunnel applies factor-200 barycentric exaggeration and a nonlinear radius transform before rendering.

**Evidence:** SolarSystemViz.tsx `EXAGGERATION = 200.0` and `Math.pow(realDist, 0.45) * ORBIT_SCALE`.

**Validity implication:** Visual clustering/geometry cannot be treated as direct physical geometry without accounting for the transform.

**Resolution criterion (not a remediation prescription):** Requires any evidentiary clustering statistic to operate on declared physical coordinates rather than unqualified display geometry.

**Strongest defense:** Visual exaggeration is normal and often necessary.

**Survives defense:** Yes

**Evidence that would change the finding:** If the visualization is explicitly non-evidentiary, this ceases to be a scientific-validity problem.

### I-006 — Major / High confidence

**Observed finding:** Key “PINN event” annotations are hardcoded labels rather than outputs of a model.

**Evidence:** SolarSystemViz.tsx `PINN_EVENTS`, including “V-E-J Torque Peak: 0.98 η,” Dust Bowl lock, and constructive interference.

**Validity implication:** The display can appear model-derived while no model generated the annotations.

**Resolution criterion (not a remediation prescription):** Requires provenance/status distinguishing annotation from computed output.

**Strongest defense:** They may be narrative waypoints for a concept visualization.

**Survives defense:** Yes

**Evidence that would change the finding:** Explicitly illustrative labeling would reduce severity.

### I-007 — Major / High confidence

**Observed finding:** The synthetic Torque Index directly drives flare/glow/corona/magnetic-field shader intensity.

**Evidence:** SolarSystemViz.tsx animate loop and Sun shader uniforms.

**Validity implication:** The visualization visually reinforces the proposed causal relation even though the driving variable is not the claimed physical torque.

**Resolution criterion (not a remediation prescription):** Requires evidentiary interpretation to be separated from decorative response.

**Strongest defense:** Reactive visualization is a design choice, not a scientific inference.

**Survives defense:** Yes

**Evidence that would change the finding:** If the UI clearly states that the response is illustrative, the validity concern narrows.

### I-008 — Major / High confidence

**Observed finding:** No automated scientific-validity tests exist in the repository; `package.json` has no test script.

**Evidence:** package.json scripts; tree has no test files.

**Validity implication:** Nothing in the repository automatically verifies the scientific calculations or claim/result mapping.

**Resolution criterion (not a remediation prescription):** Requires an executable validity/reproduction test if such claims are to be repository-verifiable.

**Strongest defense:** Frontend prototypes commonly lack automated scientific tests.

**Survives defense:** Yes

**Evidence that would change the finding:** That defense explains development stage but does not support scientific validation.

### I-009 — Minor / Medium confidence

**Observed finding:** Package versions and `index.html` import-map versions materially differ, creating environment ambiguity.

**Evidence:** package.json vs index.html import map (React 18 vs 19, Vite 5 vs 7, Recharts 2 vs 3, Three 0.160 vs 0.182-era references).

**Validity implication:** A reviewer cannot assume the same dependency resolution path across raw-browser and bundled execution.

**Resolution criterion (not a remediation prescription):** Requires an unambiguous executable environment record.

**Strongest defense:** Vite bundling may make the import map irrelevant in the deployed path.

**Survives defense:** No / finding already bounded as uncertainty or low-impact ambiguity

**Evidence that would change the finding:** If build tooling demonstrably ignores the map, the issue remains documentation/reproducibility noise only.

### I-010 — Minor / High confidence

**Observed finding:** README local-run instructions require `GEMINI_API_KEY`, but no corresponding environment-variable use is present in the audited code.

**Evidence:** README run instructions; code search for GEMINI_API_KEY/process.env/import.meta.env yielded none.

**Validity implication:** Local setup documentation contains stale or unrelated requirements.

**Resolution criterion (not a remediation prescription):** Requires documentation/execution agreement.

**Strongest defense:** The key may have been required by an earlier AI Studio wrapper.

**Survives defense:** Yes

**Evidence that would change the finding:** Historical provenance could explain it but not make the current instruction necessary.

## Provenance

The decisive inputs, transformations, runs, outputs, and forecast timestamps cannot be reconstructed from the repository.

### P-001 — Critical / High confidence

**Observed finding:** Decisive scientific inputs have no repository-level immutable identifiers, retrieval queries, hashes, or acquisition logs.

**Evidence:** README names JPL/SDO/SILSO/ERA5/OISST, but no manifests/data/query scripts exist in tree.

**Validity implication:** The exact inputs used for reported results cannot be reconstructed.

**Resolution criterion (not a remediation prescription):** Requires immutable source identifiers and transformation lineage for decisive inputs.

**Strongest defense:** Named public datasets are themselves accessible and well known.

**Survives defense:** Yes

**Evidence that would change the finding:** Dataset names alone do not identify exact slices/versions/queries; a manifest would change this.

### P-002 — Major / High confidence

**Observed finding:** Filtering, normalization, alignment, label construction, and manual intervention are not reconstructable.

**Evidence:** Diagrams.tsx shows generic “Cleaning/Alignment/Feature Eng.”; no executable transforms.

**Validity implication:** Analytic degrees of freedom and target-derived transformations cannot be audited.

**Resolution criterion (not a remediation prescription):** Requires transformation metadata/code tied to the result.

**Strongest defense:** Transformations may exist in uncommitted notebooks.

**Survives defense:** Yes

**Evidence that would change the finding:** Accessible versioned notebooks would change the finding.

### P-003 — Critical / High confidence

**Observed finding:** Displayed claims cannot be traced to experiment IDs, model versions, dataset versions, or timestamps.

**Evidence:** No run ledger/config/result metadata; values hardcoded in UI.

**Validity implication:** It is impossible to establish what exact experiment produced each claim or when.

**Resolution criterion (not a remediation prescription):** Requires claim→experiment→code→data provenance.

**Strongest defense:** A presentation site may intentionally omit backend metadata.

**Survives defense:** Yes

**Evidence that would change the finding:** A linked immutable result registry would resolve it.

### P-004 — Major / High confidence

**Observed finding:** The reference list mixes primary scientific sources with secondary/media/Wikipedia/ResearchGate sources without claim-level source mapping.

**Evidence:** README/FullPaper reference sections.

**Validity implication:** Background citations cannot be reliably mapped to the project’s strongest empirical/mechanistic statements.

**Resolution criterion (not a remediation prescription):** Requires claim-specific source provenance where external evidence is invoked.

**Strongest defense:** Mixed references can be acceptable for a survey or public-facing explainer.

**Survives defense:** Yes

**Evidence that would change the finding:** For explanatory background yes; not for decisive project-specific validation claims.

### P-005 — Critical / High confidence

**Observed finding:** The stated repository reproducibility provenance is internally false at the audited commit.

**Evidence:** README/FullPaper say complete implementation/data/notebooks are in repository; recursive tree does not contain them.

**Validity implication:** Independent researchers following the stated source trail cannot reach the claimed analysis.

**Resolution criterion (not a remediation prescription):** Requires the referenced artifact location/version to be accurate and inspectable.

**Strongest defense:** Files may have been removed after results were generated.

**Survives defense:** Yes

**Evidence that would change the finding:** A version/tag/commit containing the artifacts would materially change historical reproducibility.

## Leakage control

No specific leak is proven; instead, the scientific evaluation boundary needed to assess/control leakage is absent, leaving actual leakage unresolved and generalization claims unsupported.

### L-001 — Critical / High confidence

**Observed finding:** No inspectable evaluation boundary exists from feature construction through split/model selection/evaluation.

**Evidence:** No scientific training/split/evaluation code or run protocol in tree.

**Validity implication:** Leakage cannot be ruled out; generalization claims are uninterpretable from the artifact.

**Resolution criterion (not a remediation prescription):** Requires a traceable boundary established before target-dependent preprocessing/model selection.

**Strongest defense:** Absence of code is not proof that leakage occurred.

**Survives defense:** Yes

**Evidence that would change the finding:** Correct: this finding is absence of control, not a claim that leakage occurred.

### L-002 — Critical / High confidence

**Observed finding:** The “blind test” and apparent forecast claims lack timestamped model/data freezes demonstrating that outcomes were unavailable when predictions were issued.

**Evidence:** App validation summary; README SC25/Kuroshio claims; no forecast registry/run timestamps.

**Validity implication:** Retrospective fitting and genuine prospective prediction cannot be distinguished.

**Resolution criterion (not a remediation prescription):** Requires dated prediction/model/data-cutoff evidence.

**Strongest defense:** The predictions may genuinely have been made earlier outside the repository.

**Survives defense:** Yes

**Evidence that would change the finding:** Contemporaneous immutable forecast artifacts would change the finding.

### L-003 — Unresolved / Medium confidence

**Observed finding:** Actual target leakage or post-hoc tuning cannot be determined because the underlying scientific pipeline is absent.

**Evidence:** Missing training/evaluation implementation and provenance.

**Validity implication:** The audit must not accuse the project of a specific leak without a dataflow path.

**Resolution criterion (not a remediation prescription):** Requires the missing pipeline/run history before the question is decidable.

**Strongest defense:** No defense needed: this is explicitly an uncertainty finding.

**Survives defense:** No / finding already bounded as uncertainty or low-impact ambiguity

**Evidence that would change the finding:** The underlying pipeline would make the issue testable.

## UI and claim integrity

The interface repeatedly presents proposed, mock, hardcoded, or untraceable quantities using the visual and verbal grammar of achieved scientific validation.

### U-001 — Critical / High confidence

**Observed finding:** The interface states that the framework “is validated” and presents achieved-looking performance/significance metrics without inspectable supporting results.

**Evidence:** App.tsx Validation Protocols; Hero.tsx; Navigation.tsx.

**Validity implication:** A non-expert reader can reasonably infer completed empirical validation from a presentation layer that does not contain it.

**Resolution criterion (not a remediation prescription):** Requires claim status and evidence provenance sufficient to distinguish target/proposal from achieved result.

**Strongest defense:** The page title calls itself a “Survey,” which may signal a conceptual document.

**Survives defense:** Yes

**Evidence that would change the finding:** The specific words “validated,” “blind test,” “5σ,” and numeric achievements override that ambiguity.

### U-002 — Critical / High confidence

**Observed finding:** Mock flare data are presented under GOES/forcing correlation labels and paired with a textual statistical finding, while “mock” appears only in a source-code comment.

**Evidence:** FlareCorrelationChart.tsx top comment versus rendered title/axes; App.tsx r=0.89 finding.

**Validity implication:** The visible artifact does not disclose that the plotted points are mock, so users can mistake synthetic points for observations.

**Resolution criterion (not a remediation prescription):** Requires visible epistemic status attached to the chart/result.

**Strongest defense:** The chart was likely intended as a prototype placeholder.

**Survives defense:** Yes

**Evidence that would change the finding:** Prototype intent does not make the visible empirical framing accurate.

### U-003 — Critical / High confidence

**Observed finding:** Timeline labels “DeepXDE predictive mode active,” “High-Fidelity Training,” and similar modes are selected solely from year ranges, not engine execution.

**Evidence:** Timeline.tsx mode logic.

**Validity implication:** The UI represents nonexistent computational state as active scientific processing.

**Resolution criterion (not a remediation prescription):** Requires displayed mode to correspond to actual execution/status or be explicitly illustrative.

**Strongest defense:** The timeline may be storytelling, not a runtime monitor.

**Survives defense:** Yes

**Evidence that would change the finding:** The language “active” and “training” is operational rather than purely historical.

### U-004 — Major / High confidence

**Observed finding:** Physical terms such as N-body integration, torque, tidal shear, and causal flow are used where the implemented visual quantities are simplified or synthetic.

**Evidence:** App/README labels; SolarSystemViz implementation.

**Validity implication:** Terminology can cause users to attribute physical fidelity to the visualization that it does not have.

**Resolution criterion (not a remediation prescription):** Requires semantic alignment between displayed label and implemented quantity.

**Strongest defense:** Scientific concepts may be described in the paper even if the visualization is schematic.

**Survives defense:** Yes

**Evidence that would change the finding:** Schematic status would need to be consistently visible where the quantity is displayed.

### U-005 — Critical / High confidence

**Observed finding:** 99.8% historical accuracy, 94.2% blind test, 5σ confidence, and 10× improvement are foregrounded without traceable source artifacts.

**Evidence:** App.tsx Validation Summary/Performance.

**Validity implication:** High-certainty numbers materially overstate the evidence available from the repository.

**Resolution criterion (not a remediation prescription):** Requires inspectable provenance and uncertainty for each metric.

**Strongest defense:** They could summarize external analyses.

**Survives defense:** Yes

**Evidence that would change the finding:** Linked immutable external results would alter the conclusion.

### U-006 — Major / High confidence

**Observed finding:** The Sun’s apparent activity is programmatically increased by the synthetic Torque Index.

**Evidence:** SolarSystemViz shader thresholds/glow/corona updated from `calculateTorqueIndex`.

**Validity implication:** Users may perceive visual co-variation as a physical/model simulation rather than an authored mapping.

**Resolution criterion (not a remediation prescription):** Requires the evidentiary status of the reactive visual to be unambiguous.

**Strongest defense:** This is an artistic/educational animation and not intended as evidence.

**Survives defense:** Yes

**Evidence that would change the finding:** If clearly labeled illustrative, this becomes a minor/none validity issue.

### U-007 — Major / High confidence

**Observed finding:** Architecture/pipeline diagrams visually depict active JPL/SDO/ERA5 → DeepXDE → forecast processing that is not implemented in the audited runtime.

**Evidence:** Diagrams.tsx SystemArchDiagram/PipelineDiagram.

**Validity implication:** The interface conflates proposed architecture with deployed implementation.

**Resolution criterion (not a remediation prescription):** Requires status distinction between proposed and executed pipeline.

**Strongest defense:** Architecture diagrams often document intended rather than current systems.

**Survives defense:** Yes

**Evidence that would change the finding:** A visible “proposed architecture” status would change interpretation.

### U-008 — Major / High confidence

**Observed finding:** Economic and operational utility claims are presented downstream of unestablished forecast validity.

**Evidence:** Hero $2T; App $40B/$188B/5–10yr; README utility recommendations.

**Validity implication:** Benefit/operational conclusions inherit unsupported forecast assumptions.

**Resolution criterion (not a remediation prescription):** Requires a validated decision/forecast chain and explicit benefit assumptions before treating values as project utility evidence.

**Strongest defense:** Economic figures may be scenario-scale impact estimates rather than model-attributable benefits.

**Survives defense:** Yes

**Evidence that would change the finding:** If framed strictly as external scenario exposure rather than BURGAMOTS-derived benefit, severity would fall.

### U-009 — Major / High confidence

**Observed finding:** The available chart type system distinguishes Observed/Prediction/Consensus but not synthetic/proposed/computed/tested/validated status.

**Evidence:** types.ts `ChartDataPoint`; visible charts.

**Validity implication:** Synthetic and empirical quantities can occupy the same visual grammar without an epistemic status boundary.

**Resolution criterion (not a remediation prescription):** Requires visible status sufficient to prevent category confusion.

**Strongest defense:** Types need not encode every UI semantic if status is expressed elsewhere.

**Survives defense:** Yes

**Evidence that would change the finding:** No consistent elsewhere-status layer was found for the decisive charts.
